const bigRedButton = require('./big-red-button')
const { exec } = require('child_process')

const openCallback = () => {}
const pushCallback = () => {
  exec('./mictoggle.sh')
}
const closeCallback = () => {}
const debug = false

bigRedButton(openCallback, pushCallback, closeCallback, debug)
